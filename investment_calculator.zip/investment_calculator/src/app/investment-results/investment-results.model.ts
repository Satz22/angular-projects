export interface InvestmentResult {
  // year: number;
  // interest: number;
  // valueEndOfYear: number;
  // totalInterest: number;
  // totalAmountInvested: number;

  initialInvestment: number;
  duration: number;
  expectedReturn: number;
  annualInvestment: number;
}
[];
