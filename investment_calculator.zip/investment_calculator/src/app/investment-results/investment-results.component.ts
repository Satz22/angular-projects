import { Component, inject } from '@angular/core';
import { InvestmentService } from '../investment.service';

import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-investment-results',
  standalone: true,
  templateUrl: './investment-results.component.html',
  imports: [CommonModule],
  styleUrl: './investment-results.component.css',
})
export class InvestmentResultsComponent {
  private investmentService = inject(InvestmentService);

  results = this.investmentService.resultData.asReadonly();
}
// results = input<
//   {
//     year: number;
//     interest: number;
//     valueEndOfYear: number;
//     annualInvestment: number;
//     totalInterest: number;
//     totalAmountInvested: number;
//     initialInvestment: number;
//     duration: number;
//     expectedReturn: number;
//   }[]
// >();

// @Input() results?: {
//   year: number;
//   interest: number;
//   valueEndOfYear: number;
//   annualInvestment: number;
//   totalInterest: number;
//   totalAmountInvested: number;
// }[];
