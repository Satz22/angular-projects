export interface UserInput {
  initialInvestment: number;
  expectedReturn: number;
  annualInvestment: number;
  duration: number;
}
