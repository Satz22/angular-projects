export interface NewTaskData {
  title: string;
  summary: string;
  date: string;
}
